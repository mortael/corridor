LOGIN_URL = 'https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyPassword'
GOOGLE_KEY = 'AIzaSyA4ybnBlx6M6kgFfjGP5vy4-6wlQQQe5z8'

API = 'https://content-cache.watchcorridor.com/channels/v11'
SHOWS = API + '/shows'
MAIN = API + '?hero=false&showFree=true'
SEASON = API + '/season/'

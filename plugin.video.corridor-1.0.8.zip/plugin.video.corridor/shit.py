import base64


def decryptTvApp(e, t="dbjvw93j6kvkq"):
    try:
        n = base64.b64decode(e).decode()
        s = ""
        r = 0
        for i in range(len(n)):
            o = ord(n[i])
            a = ord(t[r % len(t)])
            u = o ^ a
            s += chr(u)
            r += 1
        return s
    except:
        return e

url = decryptTvApp("DBYeBgQDHEVTWVgfGQEWHBcHSR0eWUQeBwJLIyc1MlhAHhgGRR5JWxYFHRJXDltmDykzPy8hHRE4CAQNXzQ/PTwFUztQEkFDA0QOBVZAUltSTkIIB1sH")
print(url)
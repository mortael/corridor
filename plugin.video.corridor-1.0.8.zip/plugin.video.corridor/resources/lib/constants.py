ANCHOR_URL = 'https://www.google.com/recaptcha/enterprise/anchor?ar=1&k=6LeL41IoAAAAAJZdOVxrDQLXoHffIxt0-lqGeig_&co=aHR0cHM6Ly93d3cuY29ycmlkb3JkaWdpdGFsLmNvbTo0NDM.&hl=en&v=pxZcVU8Dk73FyvFvdCgp2MSG&size=invisible&cb=k7yaql5jw3td'
RELOAD_URL = 'https://www.google.com/recaptcha/enterprise/reload?k=6LeL41IoAAAAAJZdOVxrDQLXoHffIxt0-lqGeig_'
APPCHECK_URL = 'https://content-firebaseappcheck.googleapis.com/v1/projects/watch-corridor/apps/1:390078941029:web:37dc352540c8a451f5c38c:exchangeRecaptchaEnterpriseToken?key=AIzaSyA3ndgjGDib-HOvDezM-cKl00NcncWtN50'
LOGIN_URL = 'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyA3ndgjGDib-HOvDezM-cKl00NcncWtN50'


API = 'https://content-cache.watchcorridor.com/channels/v11'
SHOWS = API + '/shows'
MAIN = API + '?hero=false&showFree=true'
SEASON = API + '/season/'

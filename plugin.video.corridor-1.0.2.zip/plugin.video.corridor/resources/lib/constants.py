LOGIN_URL = 'https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyPassword'
GOOGLE_KEY = 'AIzaSyA4ybnBlx6M6kgFfjGP5vy4-6wlQQQe5z8'

SHOWS = 'https://content-cache.watchcorridor.com/v7/channels/shows'
MAIN = 'https://content-cache.watchcorridor.com/v7/channels?hero=true&showFree=true'
SEARCH = 'https://content.watchcorridor.com/v2/search?s='